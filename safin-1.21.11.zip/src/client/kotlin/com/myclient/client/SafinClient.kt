package com.myclient.client

import net.fabricmc.api.ClientModInitializer

object SafinClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}