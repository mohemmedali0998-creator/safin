package me.shield.ac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ShieldAC extends JavaPlugin implements CommandExecutor {

    final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();
    final Set<UUID> alertsOff = ConcurrentHashMap.newKeySet();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new Checks(this), this);
        getCommand("shieldac").setExecutor(this);
        getLogger().info("ShieldAC enabled. mode=" + getConfig().getString("mode"));
    }

    boolean enforce() {
        return !"alert".equalsIgnoreCase(getConfig().getString("mode", "enforce"));
    }

    private void decay(PlayerData d, long now) {
        double sec = (now - d.lastDecay) / 1000.0;
        d.lastDecay = now;
        d.score = Math.max(0, d.score - sec * getConfig().getDouble("score.decay-per-second", 0.25));
    }

    /** نقاط تتجمع، ولما توصل الحد = كيك */
    void flag(Player p, PlayerData d, String check, double weight, String info) {
        decay(d, System.currentTimeMillis());
        d.score += weight;
        alert(p, check, info, d.score);
        if (d.score >= getConfig().getDouble("score.kick-score", 12)) punish(p, d);
    }

    /** مخالفة مستحيلة = كيك فوري */
    void instant(Player p, PlayerData d, String check, String info) {
        alert(p, check + " [INSTANT]", info, d.score);
        punish(p, d);
    }

    private void punish(Player p, PlayerData d) {
        if (!enforce()) return;
        d.score = 0;
        p.kick(Component.text(getConfig().getString("kick-message", "Unfair advantage")));
    }

    /** تسجيل بدون نقاط (للـ lagback) */
    void record(Player p, String check, String info) {
        alert(p, check, info, 0);
    }

    private void alert(Player p, String check, String info, double vl) {
        String msg = String.format("§c[ShieldAC] §f%s §7failed §c%s §7(%s) §7vl=%.1f",
                p.getName(), check, info, vl);
        if (getConfig().getBoolean("alerts.console", true)) getLogger().warning(msg.replaceAll("§.", ""));
        if (!getConfig().getBoolean("alerts.ingame", false)) return;
        Component c = LegacyComponentSerializer.legacySection().deserialize(msg);
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.hasPermission("shieldac.alerts") && !alertsOff.contains(o.getUniqueId())) o.sendMessage(c);
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("shieldac.admin")) {
            s.sendMessage("No permission.");
            return true;
        }
        String sub = a.length > 0 ? a[0].toLowerCase() : "status";
        switch (sub) {
            case "reload" -> {
                reloadConfig();
                s.sendMessage("§aShieldAC config reloaded. mode=" + getConfig().getString("mode"));
            }
            case "alerts" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
                if (alertsOff.remove(p.getUniqueId())) s.sendMessage("§aAlerts ON");
                else { alertsOff.add(p.getUniqueId()); s.sendMessage("§eAlerts OFF"); }
            }
            default -> s.sendMessage("§7ShieldAC mode=§f" + getConfig().getString("mode")
                    + " §7tracked=§f" + data.size());
        }
        return true;
    }
}
