package me.shield.ac;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

public class PlayerData {
    // rotation
    float lastYaw, lastPitch;
    boolean hasRot;
    double lastDYaw, lastDPitch;
    long lastSnap;
    int robotic;

    // exemptions / score
    long exemptUntil;
    double score;
    long lastDecay = System.currentTimeMillis();

    // combat
    long lastAttackMs;
    int attackTick = -1;
    UUID attackTarget;
    UUID lastTarget;
    long lastTargetMs;
    final Deque<Long> attackTimes = new ArrayDeque<>();
    final Deque<Long> intervals = new ArrayDeque<>();
    final Deque<Long> airHits = new ArrayDeque<>();

    // elytra
    long winStart;
    double winDist;
    long lastBoost;

    // strafe
    double lastAngle;
    boolean hasAngle;
    int strafeVL;
    final Deque<Double> radii = new ArrayDeque<>();
    final Deque<Double> dAngles = new ArrayDeque<>();

    void clearStrafe() {
        radii.clear();
        dAngles.clear();
        hasAngle = false;
        strafeVL = 0;
    }
}
