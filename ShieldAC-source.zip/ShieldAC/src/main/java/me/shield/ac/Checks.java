package me.shield.ac;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.Deque;
import java.util.UUID;

public class Checks implements Listener {

    private final ShieldAC pl;

    public Checks(ShieldAC pl) {
        this.pl = pl;
    }

    // ───────────── helpers ─────────────
    private PlayerData d(Player p) {
        return pl.data.computeIfAbsent(p.getUniqueId(), k -> new PlayerData());
    }

    private boolean skip(Player p) {
        return p.getGameMode() == GameMode.SPECTATOR || p.hasPermission("shieldac.bypass");
    }

    private void cancel(Cancellable c) {
        if (c != null && pl.enforce()) c.setCancelled(true);
    }

    private double cfg(String path, double def) {
        return pl.getConfig().getDouble(path, def);
    }

    private boolean on(String path, boolean def) {
        return pl.getConfig().getBoolean(path, def);
    }

    private static double wrapDeg(double a) {
        a = (a + 180) % 360;
        if (a < 0) a += 360;
        return a - 180;
    }

    private static double wrapRad(double a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static double gcd(double a, double b) {
        while (b > 1e-3) {
            double r = a % b;
            a = b;
            b = r;
        }
        return a;
    }

    private static double mean(Deque<Double> q) {
        double s = 0;
        for (double v : q) s += v;
        return s / q.size();
    }

    private static double std(Deque<? extends Number> q) {
        double m = 0;
        for (Number v : q) m += v.doubleValue();
        m /= q.size();
        double s = 0;
        for (Number v : q) s += Math.pow(v.doubleValue() - m, 2);
        return Math.sqrt(s / q.size());
    }

    private static void push(Deque<Double> q, double v, int cap) {
        q.addLast(v);
        while (q.size() > cap) q.pollFirst();
    }

    /** فحوص الأورا: كيك فوري (أو نقاط إذا instant-kick: false) */
    private void aura(Player p, PlayerData d, Cancellable c, String check, double weight, String info) {
        cancel(c);
        if (on("combat.instant-kick", true)) pl.instant(p, d, check, info);
        else pl.flag(p, d, check, weight, info);
    }

    /** لاج باك: يرجّع اللاعب بدون كيك */
    private void lagback(Player p, PlayerData d, PlayerMoveEvent e, Location dest, String check, String info) {
        pl.record(p, check, info);
        if (!pl.enforce()) return;
        d.lastSetback = System.currentTimeMillis();
        Location cur = e.getTo();
        if (dest == null || cur == null || dest.getWorld() == null || !dest.getWorld().equals(cur.getWorld())) {
            e.setCancelled(true);
        } else {
            Location l = dest.clone();
            l.setYaw(cur.getYaw());
            l.setPitch(cur.getPitch());
            e.setTo(l);
        }
    }

    // ───────────── exemptions ─────────────
    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        PlayerData d = d(e.getPlayer());
        long now = System.currentTimeMillis();
        if (now - d.lastSetback < 300) return; // تيليبورت من الحماية نفسها، ما نعفيه
        d.exemptUntil = now + 1500;
        d.winStart = 0;
        d.winDist = 0;
        d.clearStrafe();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pl.data.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            d(p).exemptUntil = System.currentTimeMillis() + 1500; // knockback
        }
    }

    // دفع من انفجار / Wind Charge (يُستخدم للسرعة والطيران الأرضي فقط، مو للإليترا)
    @EventHandler(priority = EventPriority.MONITOR)
    public void onVelocity(PlayerVelocityEvent e) {
        d(e.getPlayer()).velExemptUntil = System.currentTimeMillis() + 1500;
    }

    // ───────────── movement ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (skip(p)) return;
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        Location from = e.getFrom(), to = e.getTo();
        if (to == null) return;

        // تجميد قصير بعد لاج باك الستارف
        if (now < d.freezeUntil) {
            cancel(e);
            return;
        }

        // --- rotation (Snap + robotic aim) ---
        float yaw = to.getYaw(), pitch = to.getPitch();
        if (d.hasRot) {
            double dYaw = Math.abs(wrapDeg(yaw - d.lastYaw));
            double dPitch = Math.abs(pitch - d.lastPitch);

            if (d.lastDYaw > cfg("combat.snap-min-delta", 35) && dYaw < cfg("combat.snap-return-delta", 1.5)) {
                d.lastSnap = now;
            }

            if (on("combat.enable-gcd", false) && now - d.lastAttackMs < 600 && dPitch > 0.3 && d.lastDPitch > 0.3) {
                double g = gcd(dPitch, d.lastDPitch);
                if (g < 0.003) d.robotic++;
                else d.robotic = Math.max(0, d.robotic - 1);
                if (d.robotic >= 8) {
                    d.robotic = 0;
                    aura(p, d, null, "Aura (Aim GCD)", 1.0, "robotic rotation");
                }
            }
            d.lastDYaw = dYaw;
            d.lastDPitch = dPitch;
        }
        d.lastYaw = yaw;
        d.lastPitch = pitch;
        d.hasRot = true;

        boolean gliding = p.isGliding();
        if (gliding) d.lastGlide = now;

        boolean exempt = now < d.exemptUntil || p.isInsideVehicle()
                || p.getGameMode() == GameMode.CREATIVE || p.getAllowFlight();
        if (exempt) {
            d.winStart = 0;
            d.winDist = 0;
            d.airTicks = 0;
            d.hoverTicks = 0;
            d.clearStrafe();
            return;
        }

        if (gliding) {
            // ---------- Elytra speed: لاج باك ----------
            d.airTicks = 0;
            d.hoverTicks = 0;
            double dist = from.distance(to);
            double maxBps = cfg("elytra.max-speed-bps", 80);
            double tol = 1 + cfg("elytra.tolerance", 0.04);

            if (dist > maxBps / 20.0 * tol) {
                d.winStart = 0;
                d.winDist = 0;
                lagback(p, d, e, null, "Elytra Speed", String.format("%.2f b/t", dist));
                return;
            }
            if (d.winStart == 0) {
                d.winStart = now;
                d.winDist = 0;
                d.safe = from.clone();
            }
            d.winDist += dist;
            long el = now - d.winStart;
            if (el >= 1000) {
                double bps = d.winDist / (el / 1000.0);
                Location safe = d.safe;
                d.winStart = 0;
                d.winDist = 0;
                if (bps > maxBps * tol) {
                    lagback(p, d, e, safe, "Elytra Speed", String.format("%.1f b/s", bps));
                    return;
                }
            }
        } else {
            d.winStart = 0;
            d.winDist = 0;
            if (!groundChecks(p, d, e, from, to, now)) return;
        }

        strafe(p, d, e, now, to);
    }

    // ───────────── speed + fly (غير الإليترا): لاج باك ─────────────
    private boolean groundChecks(Player p, PlayerData d, PlayerMoveEvent e, Location from, Location to, long now) {
        if (now - d.lastGlide < 2500 || now < d.velExemptUntil || p.isRiptiding()) {
            d.airTicks = 0;
            d.hoverTicks = 0;
            return true;
        }
        World w = to.getWorld();
        if (w == null) return true;

        BoundingBox bb = p.getBoundingBox().clone().shift(
                to.getX() - from.getX(), to.getY() - from.getY(), to.getZ() - from.getZ());

        boolean special = scan(w, bb.clone().expand(0.1), false)
                || scan(w, bb.clone().expand(0.1, 2.0, 0.1), true);
        boolean grounded = touchingGround(w, bb, 0.15);

        // --- Speed ---
        double hor = Math.hypot(to.getX() - from.getX(), to.getZ() - from.getZ());
        double sp = p.getWalkSpeed() / 0.2;
        PotionEffect se = p.getPotionEffect(PotionEffectType.SPEED);
        if (se != null) sp *= 1 + 0.2 * (se.getAmplifier() + 1);
        boolean ice = to.clone().subtract(0, 0.5, 0).getBlock().getType().name().contains("ICE")
                || to.clone().subtract(0, 1.5, 0).getBlock().getType().name().contains("ICE");
        double limit = cfg("ground.max-bpt", 0.62) * sp * (ice ? 2.0 : 1.0);
        if (hor > limit) {
            lagback(p, d, e, null, "Speed", String.format("%.2f b/t > %.2f", hor, limit));
            return false;
        }

        // --- Fly ---
        if (grounded || special || p.hasPotionEffect(PotionEffectType.LEVITATION)) {
            d.airTicks = 0;
            d.hoverTicks = 0;
            if (grounded) d.lastGround = from.clone();
            return true;
        }

        d.airTicks++;
        double dy = to.getY() - from.getY();
        PotionEffect je = p.getPotionEffect(PotionEffectType.JUMP_BOOST);
        int jb = je == null ? 0 : je.getAmplifier() + 1;

        String why = null;
        if (dy > cfg("fly.max-rise", 0.55) + 0.2 * jb) {
            why = String.format("rise %.2f", dy);
        } else if (dy > 0.003 && d.airTicks > 10 + 4 * jb) {
            why = "rising in air";
        } else {
            if (Math.abs(dy) < 0.005) d.hoverTicks++;
            else d.hoverTicks = 0;
            if (d.hoverTicks >= (int) cfg("fly.hover-ticks", 6)) why = "hover";
        }
        if (why != null) {
            d.airTicks = 0;
            d.hoverTicks = 0;
            lagback(p, d, e, d.lastGround, "Fly", why);
            return false;
        }
        return true;
    }

    /** هل اللاعب واقف على بلوك صلب؟ (محسوب من السيرفر، مو من الكلينت) */
    private boolean touchingGround(World w, BoundingBox bb, double depth) {
        BoundingBox probe = new BoundingBox(bb.getMinX(), bb.getMinY() - depth, bb.getMinZ(),
                bb.getMaxX(), bb.getMinY() + 0.002, bb.getMaxZ());
        for (int x = (int) Math.floor(probe.getMinX()); x <= (int) Math.floor(probe.getMaxX()); x++) {
            for (int y = (int) Math.floor(probe.getMinY()); y <= (int) Math.floor(probe.getMaxY()); y++) {
                for (int z = (int) Math.floor(probe.getMinZ()); z <= (int) Math.floor(probe.getMaxZ()); z++) {
                    if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                    Block b = w.getBlockAt(x, y, z);
                    if (b.isPassable()) continue;
                    if (b.getCollisionShape().overlaps(probe.clone().shift(-x, -y, -z))) return true;
                }
            }
        }
        return false;
    }

    /** بلوكات خاصة (ماء، سلالم، شبك، سلايم...) تعفي من فحص الطيران */
    private boolean scan(World w, BoundingBox box, boolean bounceOnly) {
        for (int x = (int) Math.floor(box.getMinX()); x <= (int) Math.floor(box.getMaxX()); x++) {
            for (int y = (int) Math.floor(box.getMinY()); y <= (int) Math.floor(box.getMaxY()); y++) {
                for (int z = (int) Math.floor(box.getMinZ()); z <= (int) Math.floor(box.getMaxZ()); z++) {
                    if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                    Block b = w.getBlockAt(x, y, z);
                    Material m = b.getType();
                    if (m.isAir()) continue;
                    boolean bounce = m == Material.SLIME_BLOCK || m == Material.HONEY_BLOCK || Tag.BEDS.isTagged(m);
                    if (bounceOnly) {
                        if (bounce) return true;
                        continue;
                    }
                    if (bounce || b.isLiquid() || Tag.CLIMBABLE.isTagged(m)
                            || m == Material.COBWEB || m == Material.SWEET_BERRY_BUSH
                            || m == Material.POWDER_SNOW || m == Material.BUBBLE_COLUMN
                            || m == Material.SCAFFOLDING) return true;
                }
            }
        }
        return false;
    }

    // ───────────── target strafe: لاج باك ─────────────
    private void strafe(Player p, PlayerData d, PlayerMoveEvent e, long now, Location to) {
        if (d.lastTarget == null || now - d.lastTargetMs > 3000) {
            d.clearStrafe();
            return;
        }
        Player t = Bukkit.getPlayer(d.lastTarget);
        if (t == null || !t.getWorld().equals(to.getWorld())) {
            d.clearStrafe();
            return;
        }
        double dx = to.getX() - t.getLocation().getX();
        double dz = to.getZ() - t.getLocation().getZ();
        double radius = Math.hypot(dx, dz);
        double ang = Math.atan2(dz, dx);

        if (d.hasAngle) {
            push(d.radii, radius, 40);
            push(d.dAngles, wrapRad(ang - d.lastAngle), 40);
        }
        d.lastAngle = ang;
        d.hasAngle = true;
        if (d.radii.size() < 40) return;

        double mr = mean(d.radii);
        double sd = std(d.radii);
        double absSum = 0;
        int pos = 0, neg = 0;
        for (double a : d.dAngles) {
            absSum += Math.abs(a);
            if (a > 0) pos++;
            else if (a < 0) neg++;
        }
        double avgAbs = absSum / d.dAngles.size();
        double sameDir = Math.max(pos, neg) / (double) d.dAngles.size();

        Vector toT = t.getBoundingBox().getCenter().subtract(p.getEyeLocation().toVector());
        double lookAng = Math.toDegrees(p.getEyeLocation().getDirection().angle(toT));

        boolean circling = mr > cfg("strafe.min-radius", 1.5) && mr < cfg("strafe.max-radius", 4.5)
                && sd < cfg("strafe.max-radius-stddev", 0.08)
                && avgAbs > cfg("strafe.min-angular-speed", 0.04)
                && sameDir > cfg("strafe.same-direction-ratio", 0.9)
                && lookAng < cfg("strafe.look-angle", 20);

        if (circling) {
            d.strafeVL++;
            if (d.strafeVL >= (int) cfg("strafe.trigger-ticks", 12)) {
                d.clearStrafe();
                d.freezeUntil = now + 400;
                lagback(p, d, e, null, "Target Strafe", String.format("r=%.2f sd=%.3f", mr, sd));
            }
        } else {
            d.strafeVL = Math.max(0, d.strafeVL - 2);
        }
    }

    // ───────────── firework boost: إلغاء الصاروخ ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBoost(PlayerElytraBoostEvent e) {
        Player p = e.getPlayer();
        if (skip(p)) return;
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        if (now - d.lastBoost < cfg("elytra.firework-min-interval-ms", 150)) {
            cancel(e);
            pl.record(p, "Firework Spam", (now - d.lastBoost) + "ms");
            return;
        }
        d.lastBoost = now;
    }

    // ───────────── combat: كيك فوري ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (skip(p)) return;

        Entity victim = e.getEntity();
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        int tick = Bukkit.getCurrentTick();

        // ضربة وحدة بالتك، وهدف واحد
        if (d.attackTick == tick) {
            cancel(e);
            if (!victim.getUniqueId().equals(d.attackTarget)) {
                aura(p, d, e, "Aura (Multi-Target)", 4.0, "2 targets in 1 tick");
            }
            return;
        }
        d.attackTick = tick;
        d.attackTarget = victim.getUniqueId();

        // --- reach ---
        Location eye = p.getEyeLocation();
        BoundingBox bb = victim.getBoundingBox();
        double cx = Math.max(bb.getMinX(), Math.min(eye.getX(), bb.getMaxX()));
        double cy = Math.max(bb.getMinY(), Math.min(eye.getY(), bb.getMaxY()));
        double cz = Math.max(bb.getMinZ(), Math.min(eye.getZ(), bb.getMaxZ()));
        double reach = eye.toVector().distance(new Vector(cx, cy, cz));
        double tol = Math.min(p.getPing(), 250) * cfg("combat.ping-tolerance-per-ms", 0.002);

        if (reach > cfg("combat.reach-kick", 4.5) + tol) {
            aura(p, d, e, "Aura (Reach)", 3.0, String.format("%.2f", reach));
            return;
        }
        if (reach > cfg("combat.reach-max", 3.0) + 0.3 + tol) {
            cancel(e);
            pl.record(p, "Reach (hit blocked)", String.format("%.2f", reach));
            return;
        }

        // --- angle ---
        if (on("combat.enable-angle", true) && reach > 1.5) {
            Vector toV = bb.getCenter().subtract(eye.toVector());
            double ang = Math.toDegrees(eye.getDirection().angle(toV));
            if (ang > cfg("combat.max-angle", 60)) {
                aura(p, d, e, "Aura (Angle)", 1.5, String.format("%.0f deg", ang));
                return;
            }
        }

        // --- snap ---
        if (now - d.lastSnap < cfg("combat.snap-window-ms", 150)) {
            d.lastSnap = 0;
            aura(p, d, e, "Aura (Snap)", 3.0, "rotation snap + hit");
            return;
        }

        // --- CPS ---
        d.attackTimes.addLast(now);
        while (!d.attackTimes.isEmpty() && now - d.attackTimes.peekFirst() > 1000) d.attackTimes.pollFirst();
        if (d.attackTimes.size() > cfg("combat.max-cps", 25)) {
            aura(p, d, e, "Aura (CPS)", 2.0, d.attackTimes.size() + " hits/s");
            return;
        }

        // --- timing variance ---
        if (d.lastAttackMs > 0) {
            long iv = now - d.lastAttackMs;
            if (iv < 1000) {
                d.intervals.addLast(iv);
                while (d.intervals.size() > 25) d.intervals.pollFirst();
            }
        }
        d.lastAttackMs = now;
        if (on("combat.enable-timing", true) && d.intervals.size() >= 20) {
            double sd = std(d.intervals);
            double avg = 0;
            for (long v : d.intervals) avg += v;
            avg /= d.intervals.size();
            if (avg < 400 && sd < cfg("combat.timing-stddev-ms", 7)) {
                d.intervals.clear();
                aura(p, d, e, "Aura (Timing)", 3.0, String.format("sd=%.1fms", sd));
                return;
            }
        }

        // --- elytra target: 5 ضربات بالجو خلال 10 ثواني = كيك فوري ---
        if (p.isGliding() && victim instanceof Player) {
            d.airHits.addLast(now);
            long win = (long) (cfg("elytra.target.window-seconds", 10) * 1000);
            while (!d.airHits.isEmpty() && now - d.airHits.peekFirst() > win) d.airHits.pollFirst();
            if (d.airHits.size() >= (int) cfg("elytra.target.hits", 5)) {
                int n = d.airHits.size();
                d.airHits.clear();
                cancel(e);
                pl.instant(p, d, "Elytra Target", n + " air hits");
                return;
            }
        }

        // --- remember target for strafe check ---
        UUID id = victim.getUniqueId();
        if (victim instanceof Player) {
            if (!id.equals(d.lastTarget)) d.clearStrafe();
            d.lastTarget = id;
            d.lastTargetMs = now;
        }
    }
}
