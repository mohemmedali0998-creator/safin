package me.shield.ac;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.Deque;
import java.util.UUID;

public class Checks implements Listener {

    private final ShieldAC pl;

    public Checks(ShieldAC pl) {
        this.pl = pl;
    }

    // ───────────── helpers ─────────────
    private PlayerData d(Player p) {
        return pl.data.computeIfAbsent(p.getUniqueId(), k -> new PlayerData());
    }

    private boolean skip(Player p) {
        return p.getGameMode() == GameMode.SPECTATOR || p.hasPermission("shieldac.bypass");
    }

    private void cancel(Cancellable c) {
        if (pl.enforce()) c.setCancelled(true);
    }

    private double cfg(String path, double def) {
        return pl.getConfig().getDouble(path, def);
    }

    private static double wrapDeg(double a) {
        a = (a + 180) % 360;
        if (a < 0) a += 360;
        return a - 180;
    }

    private static double wrapRad(double a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static double gcd(double a, double b) {
        while (b > 1e-3) {
            double r = a % b;
            a = b;
            b = r;
        }
        return a;
    }

    private static double mean(Deque<Double> q) {
        double s = 0;
        for (double v : q) s += v;
        return s / q.size();
    }

    private static double std(Deque<? extends Number> q) {
        double m = 0;
        for (Number v : q) m += v.doubleValue();
        m /= q.size();
        double s = 0;
        for (Number v : q) s += Math.pow(v.doubleValue() - m, 2);
        return Math.sqrt(s / q.size());
    }

    private static void push(Deque<Double> q, double v, int cap) {
        q.addLast(v);
        while (q.size() > cap) q.pollFirst();
    }

    // ───────────── exemptions ─────────────
    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        PlayerData d = d(e.getPlayer());
        d.exemptUntil = System.currentTimeMillis() + 1500;
        d.winStart = 0;
        d.winDist = 0;
        d.clearStrafe();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        d(e.getPlayer()).exemptUntil = System.currentTimeMillis() + 2000;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pl.data.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            d(p).exemptUntil = System.currentTimeMillis() + 1500; // knockback
        }
    }

    // ───────────── movement: rotation, elytra speed, strafe ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (skip(p)) return;
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        Location from = e.getFrom(), to = e.getTo();
        if (to == null) return;

        // --- rotation (Snap + robotic aim) ---
        float yaw = to.getYaw(), pitch = to.getPitch();
        if (d.hasRot) {
            double dYaw = Math.abs(wrapDeg(yaw - d.lastYaw));
            double dPitch = Math.abs(pitch - d.lastPitch);

            if (d.lastDYaw > cfg("combat.snap-min-delta", 35) && dYaw < cfg("combat.snap-return-delta", 1.5)) {
                d.lastSnap = now;
            }

            if (now - d.lastAttackMs < 600 && dPitch > 0.3 && d.lastDPitch > 0.3) {
                double g = gcd(dPitch, d.lastDPitch);
                if (g < 0.003) d.robotic++;
                else d.robotic = Math.max(0, d.robotic - 1);
                if (d.robotic >= 8) {
                    d.robotic = 0;
                    pl.flag(p, d, "Aura (Aim GCD)", 1.0, "robotic rotation");
                }
            }
            d.lastDYaw = dYaw;
            d.lastDPitch = dPitch;
        }
        d.lastYaw = yaw;
        d.lastPitch = pitch;
        d.hasRot = true;

        boolean exempt = now < d.exemptUntil || p.isInsideVehicle() || p.getGameMode() == GameMode.CREATIVE;

        // --- elytra speed (average over 1s, lag-tolerant) ---
        if (p.isGliding() && !exempt) {
            if (d.winStart == 0) d.winStart = now;
            d.winDist += from.distance(to);
            long el = now - d.winStart;
            if (el >= 1000) {
                double bps = d.winDist / (el / 1000.0);
                double max = cfg("elytra.max-speed-bps", 80) * (1 + cfg("elytra.tolerance", 0.04));
                d.winStart = 0;
                d.winDist = 0;
                if (bps > max) {
                    cancel(e);
                    pl.instant(p, d, "Elytra Speed", String.format("%.1f b/s > %.1f", bps, max));
                    return;
                }
            }
        } else {
            d.winStart = 0;
            d.winDist = 0;
        }

        // --- target strafe ---
        strafe(p, d, now, exempt, to);
    }

    private void strafe(Player p, PlayerData d, long now, boolean exempt, Location to) {
        if (d.lastTarget == null || now - d.lastTargetMs > 3000 || exempt) {
            d.clearStrafe();
            return;
        }
        Player t = Bukkit.getPlayer(d.lastTarget);
        if (t == null || !t.getWorld().equals(to.getWorld())) {
            d.clearStrafe();
            return;
        }
        double dx = to.getX() - t.getLocation().getX();
        double dz = to.getZ() - t.getLocation().getZ();
        double radius = Math.hypot(dx, dz);
        double ang = Math.atan2(dz, dx);

        if (d.hasAngle) {
            push(d.radii, radius, 40);
            push(d.dAngles, wrapRad(ang - d.lastAngle), 40);
        }
        d.lastAngle = ang;
        d.hasAngle = true;
        if (d.radii.size() < 40) return;

        double mr = mean(d.radii);
        double sd = std(d.radii);
        double absSum = 0;
        int pos = 0, neg = 0;
        for (double a : d.dAngles) {
            absSum += Math.abs(a);
            if (a > 0) pos++;
            else if (a < 0) neg++;
        }
        double avgAbs = absSum / d.dAngles.size();
        double sameDir = Math.max(pos, neg) / (double) d.dAngles.size();

        Vector toT = t.getBoundingBox().getCenter().subtract(p.getEyeLocation().toVector());
        double lookAng = Math.toDegrees(p.getEyeLocation().getDirection().angle(toT));

        boolean circling = mr > cfg("strafe.min-radius", 1.5) && mr < cfg("strafe.max-radius", 4.5)
                && sd < cfg("strafe.max-radius-stddev", 0.08)
                && avgAbs > cfg("strafe.min-angular-speed", 0.04)
                && sameDir > cfg("strafe.same-direction-ratio", 0.9)
                && lookAng < cfg("strafe.look-angle", 20);

        if (circling) {
            d.strafeVL++;
            if (d.strafeVL >= (int) cfg("strafe.kick-after", 20)) {
                d.strafeVL = 0;
                pl.instant(p, d, "Aura (Target Strafe)",
                        String.format("r=%.2f sd=%.3f", mr, sd));
            }
        } else {
            d.strafeVL = Math.max(0, d.strafeVL - 2);
        }
    }

    // ───────────── firework boost ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBoost(PlayerElytraBoostEvent e) {
        Player p = e.getPlayer();
        if (skip(p)) return;
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        if (now - d.lastBoost < cfg("elytra.firework-min-interval-ms", 150)) {
            cancel(e);
            pl.flag(p, d, "Firework Spam", 2.0, (now - d.lastBoost) + "ms");
            return;
        }
        d.lastBoost = now;
    }

    // ───────────── combat ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (skip(p)) return;

        Entity victim = e.getEntity();
        PlayerData d = d(p);
        long now = System.currentTimeMillis();
        int tick = Bukkit.getCurrentTick();

        // ضربة وحدة بالتك، وهدف واحد
        if (d.attackTick == tick) {
            cancel(e);
            if (!victim.getUniqueId().equals(d.attackTarget)) {
                pl.flag(p, d, "Aura (Multi-Target)", 4.0, "2 targets in 1 tick");
            }
            return;
        }
        d.attackTick = tick;
        d.attackTarget = victim.getUniqueId();

        // --- reach ---
        Location eye = p.getEyeLocation();
        BoundingBox bb = victim.getBoundingBox();
        double cx = Math.max(bb.getMinX(), Math.min(eye.getX(), bb.getMaxX()));
        double cy = Math.max(bb.getMinY(), Math.min(eye.getY(), bb.getMaxY()));
        double cz = Math.max(bb.getMinZ(), Math.min(eye.getZ(), bb.getMaxZ()));
        double reach = eye.toVector().distance(new Vector(cx, cy, cz));
        double tol = Math.min(p.getPing(), 250) * cfg("combat.ping-tolerance-per-ms", 0.002);

        if (reach > cfg("combat.reach-kick", 6.0)) {
            cancel(e);
            pl.instant(p, d, "Reach", String.format("%.2f", reach));
            return;
        }
        if (reach > cfg("combat.reach-max", 3.0) + 0.3 + tol) {
            cancel(e);
            pl.flag(p, d, "Reach", 1.5, String.format("%.2f", reach));
        }

        // --- angle ---
        if (reach > 1.5) {
            Vector toV = bb.getCenter().subtract(eye.toVector());
            double ang = Math.toDegrees(eye.getDirection().angle(toV));
            if (ang > cfg("combat.max-angle", 55)) {
                pl.flag(p, d, "Aura (Angle)", 1.5, String.format("%.0f deg", ang));
            }
        }

        // --- snap ---
        if (now - d.lastSnap < cfg("combat.snap-window-ms", 150)) {
            d.lastSnap = 0;
            pl.flag(p, d, "Aura (Snap)", 3.0, "rotation snap + hit");
        }

        // --- CPS ---
        d.attackTimes.addLast(now);
        while (!d.attackTimes.isEmpty() && now - d.attackTimes.peekFirst() > 1000) d.attackTimes.pollFirst();
        if (d.attackTimes.size() > cfg("combat.max-cps", 20)) {
            cancel(e);
            pl.flag(p, d, "Aura (CPS)", 2.0, d.attackTimes.size() + " hits/s");
        }

        // --- timing variance ---
        if (d.lastAttackMs > 0) {
            long iv = now - d.lastAttackMs;
            if (iv < 1000) {
                d.intervals.addLast(iv);
                while (d.intervals.size() > 25) d.intervals.pollFirst();
            }
        }
        d.lastAttackMs = now;
        if (d.intervals.size() >= 20) {
            double sd = std(d.intervals);
            double avg = 0;
            for (long v : d.intervals) avg += v;
            avg /= d.intervals.size();
            if (avg < 400 && sd < cfg("combat.timing-stddev-ms", 7)) {
                d.intervals.clear();
                pl.flag(p, d, "Aura (Timing)", 3.0, String.format("sd=%.1fms", sd));
            }
        }

        // --- elytra target: 5 hits in 10s while gliding ---
        if (p.isGliding() && victim instanceof Player) {
            d.airHits.addLast(now);
            long win = (long) (cfg("elytra.target.window-seconds", 10) * 1000);
            while (!d.airHits.isEmpty() && now - d.airHits.peekFirst() > win) d.airHits.pollFirst();
            if (d.airHits.size() >= (int) cfg("elytra.target.hits", 5)) {
                int n = d.airHits.size();
                d.airHits.clear();
                cancel(e);
                pl.instant(p, d, "Elytra Target", n + " air hits");
                return;
            }
        }

        // --- remember target for strafe check ---
        UUID id = victim.getUniqueId();
        if (victim instanceof Player) {
            if (!id.equals(d.lastTarget)) d.clearStrafe();
            d.lastTarget = id;
            d.lastTargetMs = now;
        }
    }
}
