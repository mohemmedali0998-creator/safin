package com.myclient.client.config

import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.myclient.client.module.BoolSetting
import com.myclient.client.module.ModeSetting
import com.myclient.client.module.ModuleManager
import com.myclient.client.module.NumSetting
import net.fabricmc.loader.api.FabricLoader
import java.nio.file.Files
import java.nio.file.Path

/** Saves/loads every module's state + settings as JSON files in .minecraft/config/safin/ */
object ConfigManager {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    private val dir: Path = FabricLoader.getInstance().configDir.resolve("safin")

    var current: String = "default"
        private set

    private fun file(name: String): Path = dir.resolve("$name.json")

    fun list(): List<String> {
        return try {
            Files.createDirectories(dir)
            Files.list(dir).use { stream ->
                stream.iterator().asSequence()
                    .map { it.fileName.toString() }
                    .filter { it.endsWith(".json") }
                    .map { it.removeSuffix(".json") }
                    .sorted()
                    .toList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(name: String = current) {
        try {
            Files.createDirectories(dir)
            val root = JsonObject()
            for (m in ModuleManager.modules) {
                if (!m.implemented) continue
                val obj = JsonObject()
                obj.addProperty("enabled", m.enabled)
                val settings = JsonObject()
                for (s in m.settings) {
                    when (s) {
                        is BoolSetting -> settings.addProperty(s.name, s.value)
                        is NumSetting -> settings.addProperty(s.name, s.value)
                        is ModeSetting -> settings.addProperty(s.name, s.index)
                    }
                }
                obj.add("settings", settings)
                root.add(m.name, obj)
            }
            Files.writeString(file(name), gson.toJson(root))
            current = name
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun load(name: String): Boolean {
        val path = file(name)
        if (!Files.exists(path)) return false
        return try {
            val root = JsonParser.parseString(Files.readString(path)).asJsonObject
            for (m in ModuleManager.modules) {
                if (!m.implemented) continue
                val obj = root.get(m.name)?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
                val settings = obj.get("settings")?.takeIf { it.isJsonObject }?.asJsonObject
                if (settings != null) {
                    for (s in m.settings) {
                        val v = settings.get(s.name) ?: continue
                        try {
                            when (s) {
                                is BoolSetting -> s.value = v.asBoolean
                                is NumSetting -> s.value = v.asDouble.coerceIn(s.min, s.max)
                                is ModeSetting -> s.index = v.asInt.coerceIn(0, s.options.size - 1)
                            }
                        } catch (e: Exception) {
                        }
                    }
                }
                m.setState(obj.get("enabled")?.asBoolean ?: false)
            }
            current = name
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun saveNew(): String {
        var i = 1
        while (Files.exists(file("config$i"))) i++
        val name = "config$i"
        save(name)
        return name
    }

    fun delete(name: String) {
        try {
            Files.deleteIfExists(file(name))
        } catch (e: Exception) {
        }
    }
}
