package com.myclient.client.module

import net.minecraft.client.Minecraft

enum class ModCategory(val title: String) {
    PVP("Pvp"),
    MOVEMENT("Movement"),
    VISUAL("Visual")
}

sealed class Setting(val name: String) {
    var showIf: () -> Boolean = { true }
}

class BoolSetting(name: String, var value: Boolean) : Setting(name)

class NumSetting(
    name: String,
    var value: Double,
    val min: Double,
    val max: Double,
    val decimals: Int = 1
) : Setting(name)

class ModeSetting(name: String, val options: List<String>, var index: Int = 0) : Setting(name) {
    val value: String get() = options[index]
    fun next() {
        index = (index + 1) % options.size
    }
}

abstract class Module(val name: String, val category: ModCategory) {
    var enabled: Boolean = false
        private set

    val settings: MutableList<Setting> = mutableListOf()

    open val implemented: Boolean get() = true

    protected fun bool(name: String, default: Boolean): BoolSetting =
        BoolSetting(name, default).also { settings.add(it) }

    protected fun num(name: String, default: Double, min: Double, max: Double, decimals: Int = 1): NumSetting =
        NumSetting(name, default, min, max, decimals).also { settings.add(it) }

    protected fun mode(name: String, options: List<String>, index: Int = 0): ModeSetting =
        ModeSetting(name, options, index).also { settings.add(it) }

    open fun onEnable() {}
    open fun onDisable() {}
    open fun onTick(mc: Minecraft) {}

    fun toggle() {
        if (implemented) setState(!enabled)
    }

    fun setState(value: Boolean) {
        if (value == enabled) return
        enabled = value
        if (value) onEnable() else onDisable()
    }
}

/** A module that is listed in the menu but not written yet. */
class Planned(name: String, category: ModCategory) : Module(name, category) {
    override val implemented: Boolean get() = false
}

object ModuleManager {
    private val plannedPvp = listOf(
        "Anti Phase", "Attribute Swap", "Auto Base Place", "Auto Dripstone",
        "Auto Mine", "Auto Netherite Scrap", "Auto Sweet Berries", "Mace Killer"
    )
    private val plannedMovement = listOf(
        "Anti Knock Back", "Avoid", "Move Fix", "No Push", "Wind Hop"
    )
    private val plannedVisual = listOf(
        "Absorption", "Aspect", "Buff Effect", "Crystal Chams", "Damage Tint",
        "Dismemberment", "Free Look", "Hand Chams", "No Camera Clip", "Particles",
        "Pop Chams", "Sky Lanterns", "Swing Animations", "Throw Petard", "Totem Animation",
        "Trajectories", "View Model", "World Renderer"
    )

    val modules: List<Module> = buildList {
        add(Aura())
        add(TriggerBot())
        add(Sprint())
        add(BunnyHop())
        add(FullBright())
        listOf(
            Criticals(), MoreKnockback(), AutoWeb(), Trap(), HoleFiller(), AutoCrystal(),
            ElytraRecast(), InfiniteElytra(), ElytraTarget(), GuiMove(), LegitStrafe(), HoleAnchor(),
            HitFx(), DamageParticles()
        ).forEach { add(it) }
        plannedPvp.forEach { add(Planned(it, ModCategory.PVP)) }
        plannedMovement.forEach { add(Planned(it, ModCategory.MOVEMENT)) }
        plannedVisual.forEach { add(Planned(it, ModCategory.VISUAL)) }
    }.sortedBy { it.name }

    inline fun <reified T : Module> get(): T? = modules.firstOrNull { it is T } as T?

    fun inCategory(category: ModCategory): List<Module> =
        modules.filter { it.category == category }

    fun tick(mc: Minecraft) {
        for (m in modules) {
            if (m.enabled) m.onTick(mc)
        }
    }
}
