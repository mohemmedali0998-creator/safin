package com.myclient.client.module

import net.minecraft.client.Minecraft
import net.minecraft.tags.ItemTags
import net.minecraft.world.InteractionHand
import net.minecraft.world.effect.MobEffectInstance
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.Mob
import net.minecraft.world.entity.decoration.ArmorStand
import net.minecraft.world.entity.monster.Enemy
import net.minecraft.world.entity.player.Player
import net.minecraft.world.phys.EntityHitResult

/** Attacks the nearest target in range (for your own single-player world). */
class Aura : Module("Aura", ModCategory.PVP) {
    private val range = num("Range", 3.0, 2.0, 6.0)
    private val chance = num("Attack Chance", 100.0, 1.0, 100.0, 0)
    private val sort = mode("Sort", listOf("Distance", "Health"))
    private val players = bool("Players", false)
    private val hostiles = bool("Hostiles", true)
    private val animals = bool("Animals", false)
    private val ignoreNamed = bool("Ignore Named", false)
    private val ignoreInvisible = bool("Ignore Invisible", true)
    private val onlyWeapon = bool("Only Weapon", false)
    private val pauseEating = bool("Pause While Eating", true)
    private val rotate = bool("Rotate", false)

    private fun matches(e: LivingEntity): Boolean =
        (players.value && e is Player) ||
            (hostiles.value && e is Enemy) ||
            (animals.value && e is Mob && e !is Enemy)

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val gameMode = mc.gameMode ?: return
        val level = mc.level ?: return
        if (mc.screen != null) return
        if (pauseEating.value && player.isUsingItem) return
        if (onlyWeapon.value) {
            val held = player.mainHandItem
            if (!(held.`is`(ItemTags.SWORDS) || held.`is`(ItemTags.AXES))) return
        }
        if (player.getAttackStrengthScale(0f) < 1f) return
        if (Math.random() * 100.0 >= chance.value) return

        val r = range.value
        val candidates = level.getEntities(player, player.boundingBox.inflate(r))
            .filterIsInstance<LivingEntity>()
            .filter { e ->
                e.isAlive && e !is ArmorStand && player.distanceTo(e) <= r &&
                    !(ignoreNamed.value && e.hasCustomName()) &&
                    !(ignoreInvisible.value && e.isInvisible) &&
                    matches(e)
            }
        val target = (if (sort.index == 1) candidates.minByOrNull { it.health }
        else candidates.minByOrNull { player.distanceTo(it) }) ?: return

        if (rotate.value) face(player, target)
        Combat.strike(mc, player, target)
    }

    private fun face(player: Player, target: LivingEntity) {
        val eye = player.eyePosition
        val ty = target.y + target.bbHeight * 0.6
        val dx = target.x - eye.x
        val dz = target.z - eye.z
        val dy = ty - eye.y
        val yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0
        val pitch = -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)))
        player.yRot = yaw.toFloat()
        player.xRot = pitch.toFloat()
    }
}

/** Attacks whatever your crosshair is on, once the weapon is charged. */
class TriggerBot : Module("Trigger Bot", ModCategory.PVP) {
    private val hostilesOnly = bool("Hostiles Only", false)

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val gameMode = mc.gameMode ?: return
        if (mc.screen != null || player.isUsingItem) return
        if (player.getAttackStrengthScale(0f) < 1f) return
        val hit = mc.hitResult as? EntityHitResult ?: return
        val target = hit.entity as? LivingEntity ?: return
        if (!target.isAlive || target is ArmorStand) return
        if (hostilesOnly.value && target !is Enemy) return
        Combat.strike(mc, player, target)
    }
}

class Sprint : Module("Sprint", ModCategory.MOVEMENT) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (player.zza > 0f && !player.isUsingItem && !player.horizontalCollision) {
            player.isSprinting = true
        }
    }
}

class BunnyHop : Module("Bunny Hop", ModCategory.MOVEMENT) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (mc.screen != null || player.isUsingItem) return
        if (player.onGround() && (player.zza != 0f || player.xxa != 0f)) {
            val v = player.deltaMovement
            player.setDeltaMovement(v.x, 0.42, v.z)
        }
    }
}

class FullBright : Module("Full Bright", ModCategory.VISUAL) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val current = player.getEffect(MobEffects.NIGHT_VISION)
        if (current == null || current.duration < 300) {
            player.addEffect(MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false, false))
        }
    }

    override fun onDisable() {
        Minecraft.getInstance().player?.removeEffect(MobEffects.NIGHT_VISION)
    }
}
