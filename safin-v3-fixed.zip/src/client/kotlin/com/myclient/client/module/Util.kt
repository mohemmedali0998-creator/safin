package com.myclient.client.module

import net.minecraft.client.Minecraft
import net.minecraft.client.player.LocalPlayer
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket
import net.minecraft.util.Mth
import net.minecraft.world.InteractionHand
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.phys.BlockHitResult
import net.minecraft.world.phys.Vec3

object Util {
    fun hotbarSlot(player: Player, pred: (ItemStack) -> Boolean): Int {
        for (i in 0..8) if (pred(player.inventory.getItem(i))) return i
        return -1
    }

    fun nearestPlayer(mc: Minecraft, range: Double): Player? {
        val me = mc.player ?: return null
        val level = mc.level ?: return null
        return level.players()
            .filter { it !== me && it.isAlive && !it.isSpectator && me.distanceTo(it) <= range }
            .minByOrNull { me.distanceTo(it) }
    }

    /** Uses the item in [slot] on a block hit, then puts the old slot back. */
    fun useOn(mc: Minecraft, slot: Int, hit: BlockHitResult) {
        val player = mc.player ?: return
        val gm = mc.gameMode ?: return
        val prev = player.inventory.selectedSlot
        player.inventory.selectedSlot = slot
        gm.useItemOn(player, InteractionHand.MAIN_HAND, hit)
        player.swing(InteractionHand.MAIN_HAND)
        player.inventory.selectedSlot = prev
    }

    /** Places the item in [slot] at [pos] against any solid neighbour. */
    fun place(mc: Minecraft, pos: BlockPos, slot: Int): Boolean {
        val level = mc.level ?: return false
        if (!level.getBlockState(pos).canBeReplaced()) return false
        for (dir in Direction.values()) {
            val nb = pos.relative(dir)
            val st = level.getBlockState(nb)
            if (st.isAir || st.canBeReplaced()) continue
            val face = dir.opposite
            val hitVec = Vec3.atCenterOf(nb).add(face.stepX * 0.5, face.stepY * 0.5, face.stepZ * 0.5)
            useOn(mc, slot, BlockHitResult(hitVec, face, nb, false))
            return true
        }
        return false
    }

    fun safe(level: Level, pos: BlockPos): Boolean {
        val s = level.getBlockState(pos)
        return s.`is`(Blocks.OBSIDIAN) || s.`is`(Blocks.BEDROCK)
    }

    fun isHole(level: Level, pos: BlockPos): Boolean {
        if (!level.getBlockState(pos).isAir || !level.getBlockState(pos.above()).isAir) return false
        if (!safe(level, pos.below())) return false
        for (d in Direction.Plane.HORIZONTAL) if (!safe(level, pos.relative(d))) return false
        return true
    }
}

object Rot {
    fun yawTo(from: Vec3, to: Vec3): Float =
        (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0).toFloat()

    fun pitchTo(from: Vec3, to: Vec3): Float {
        val dx = to.x - from.x
        val dz = to.z - from.z
        return (-Math.toDegrees(Math.atan2(to.y - from.y, Math.hypot(dx, dz)))).toFloat()
    }

    fun step(cur: Float, target: Float, max: Float): Float {
        val d = Mth.wrapDegrees(target - cur)
        return cur + d.coerceIn(-max, max)
    }
}

object Combat {
    /** One attack on [target], honouring Criticals and More Knockback. Returns true if it hit. */
    fun strike(mc: Minecraft, player: LocalPlayer, target: LivingEntity): Boolean {
        val gm = mc.gameMode ?: return false
        val crit = ModuleManager.get<Criticals>()
        if (crit != null && crit.enabled && !crit.ready(player)) {
            if (player.onGround()) {
                val v = player.deltaMovement
                player.setDeltaMovement(v.x, 0.42, v.z)
            }
            return false
        }
        val kb = ModuleManager.get<MoreKnockback>()
        if (kb != null && kb.enabled && player.isSprinting) {
            player.connection.send(ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING))
            player.connection.send(ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.START_SPRINTING))
        }
        gm.attack(player, target)
        player.swing(InteractionHand.MAIN_HAND)
        return true
    }
}
