package com.myclient.client.module

import net.minecraft.client.KeyMapping
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.screens.ChatScreen
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.core.particles.ParticleTypes
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket
import net.minecraft.world.InteractionHand
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.boss.enderdragon.EndCrystal
import net.minecraft.world.item.Items
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.phys.AABB
import net.minecraft.world.phys.BlockHitResult
import net.minecraft.world.phys.Vec3

// ============================================================ PVP

class Criticals : Module("Criticals", ModCategory.PVP) {
    fun ready(p: net.minecraft.client.player.LocalPlayer): Boolean =
        p.fallDistance > 0.0 && !p.onGround() && !p.onClimbable() && !p.isInWater && !p.isPassenger
}

class MoreKnockback : Module("More Knockback", ModCategory.PVP)

class AutoWeb : Module("Auto Web", ModCategory.PVP) {
    private val range = num("Range", 5.0, 2.0, 6.0)
    private val head = bool("Also Head", false)
    private val delay = num("Delay (ticks)", 4.0, 0.0, 20.0, 0)
    private var cd = 0

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (mc.screen != null) return
        if (cd > 0) { cd--; return }
        val target = Util.nearestPlayer(mc, range.value) ?: return
        val slot = Util.hotbarSlot(player) { it.`is`(Items.COBWEB) }
        if (slot < 0) return
        val feet = target.blockPosition()
        if (Util.place(mc, feet, slot) || (head.value && Util.place(mc, feet.above(), slot))) {
            cd = delay.value.toInt()
        }
    }
}

class Trap : Module("Trap", ModCategory.PVP) {
    private val range = num("Range", 5.0, 2.0, 6.0)
    private val top = bool("Top", true)
    private val perTick = num("Blocks / Tick", 2.0, 1.0, 6.0, 0)
    private val delay = num("Delay (ticks)", 1.0, 0.0, 10.0, 0)
    private var cd = 0

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (mc.screen != null) return
        if (cd > 0) { cd--; return }
        val target = Util.nearestPlayer(mc, range.value) ?: return
        val slot = Util.hotbarSlot(player) { it.`is`(Items.OBSIDIAN) }
        if (slot < 0) return
        val t = target.blockPosition()
        val order = ArrayList<BlockPos>()
        for (h in 0..1) for (d in Direction.Plane.HORIZONTAL) order.add(t.relative(d).above(h))
        if (top.value) order.add(t.above(2))
        var placed = 0
        for (p in order) {
            if (placed >= perTick.value.toInt()) break
            if (Util.place(mc, p, slot)) placed++
        }
        if (placed > 0) cd = delay.value.toInt()
    }
}

class HoleFiller : Module("Hole Filler", ModCategory.PVP) {
    private val range = num("Range", 4.0, 2.0, 6.0)
    private val enemyRange = num("Enemy Range", 8.0, 2.0, 16.0)
    private val perTick = num("Blocks / Tick", 1.0, 1.0, 4.0, 0)
    private val delay = num("Delay (ticks)", 2.0, 0.0, 10.0, 0)
    private var cd = 0

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val level = mc.level ?: return
        if (mc.screen != null) return
        if (cd > 0) { cd--; return }
        val slot = Util.hotbarSlot(player) { it.`is`(Items.OBSIDIAN) }
        if (slot < 0) return
        val base = player.blockPosition()
        val r = range.value.toInt()
        var placed = 0
        for (dx in -r..r) for (dz in -r..r) for (dy in -2..1) {
            if (placed >= perTick.value.toInt()) break
            val p = BlockPos(base.x + dx, base.y + dy, base.z + dz)
            if (player.distanceToSqr(p.x + 0.5, p.y + 0.5, p.z + 0.5) > range.value * range.value) continue
            if (!Util.isHole(level, p)) continue
            val enemy = level.players().any {
                it !== player && it.isAlive && it.distanceToSqr(p.x + 0.5, p.y + 0.5, p.z + 0.5) <= enemyRange.value * enemyRange.value
            }
            if (!enemy) continue
            if (Util.place(mc, p, slot)) placed++
        }
        if (placed > 0) cd = delay.value.toInt()
    }
}

class AutoCrystal : Module("Auto Crystal", ModCategory.PVP) {
    private val targetRange = num("Target Range", 10.0, 3.0, 20.0)
    private val placeRange = num("Place Range", 4.5, 2.0, 6.0)
    private val breakRange = num("Break Range", 4.5, 2.0, 6.0)
    private val minSelf = num("Min Self Distance", 2.5, 0.0, 5.0)
    private val delay = num("Delay (ticks)", 2.0, 0.0, 10.0, 0)
    private val doPlace = bool("Place", true)
    private val doBreak = bool("Break", true)
    private var cd = 0

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val level = mc.level ?: return
        val gm = mc.gameMode ?: return
        if (mc.screen != null) return
        if (cd > 0) { cd--; return }
        val target = Util.nearestPlayer(mc, targetRange.value) ?: return

        if (doBreak.value) {
            val box = player.boundingBox.inflate(breakRange.value)
            val crystal = level.getEntitiesOfClass(EndCrystal::class.java, box)
                .filter { player.distanceTo(it) <= breakRange.value && it.distanceTo(target) <= 8.0 }
                .minByOrNull { it.distanceTo(target) }
            if (crystal != null) {
                gm.attack(player, crystal)
                player.swing(InteractionHand.MAIN_HAND)
                cd = delay.value.toInt()
                return
            }
        }

        if (!doPlace.value) return
        val slot = Util.hotbarSlot(player) { it.`is`(Items.END_CRYSTAL) }
        if (slot < 0) return
        val base = player.blockPosition()
        val r = placeRange.value.toInt() + 1
        var best: BlockPos? = null
        var bestDist = Double.MAX_VALUE
        for (dx in -r..r) for (dz in -r..r) for (dy in -3..3) {
            val p = BlockPos(base.x + dx, base.y + dy, base.z + dz)
            val st = level.getBlockState(p)
            if (!(st.`is`(Blocks.OBSIDIAN) || st.`is`(Blocks.BEDROCK))) continue
            if (!level.isEmptyBlock(p.above()) || !level.isEmptyBlock(p.above(2))) continue
            val center = Vec3(p.x + 0.5, p.y + 1.0, p.z + 0.5)
            if (player.eyePosition.distanceTo(center) > placeRange.value) continue
            if (player.position().distanceTo(center) < minSelf.value) continue
            val d = target.position().distanceTo(center)
            if (d > 6.0 || d >= bestDist) continue
            val box = AABB(p.x.toDouble(), p.y + 1.0, p.z.toDouble(), p.x + 1.0, p.y + 3.0, p.z + 1.0)
            if (level.getEntities(null, box).isNotEmpty()) continue
            best = p
            bestDist = d
        }
        val p = best ?: return
        Util.useOn(mc, slot, BlockHitResult(Vec3(p.x + 0.5, p.y + 1.0, p.z + 0.5), Direction.UP, p, false))
        cd = delay.value.toInt()
    }
}

// ============================================================ MOVEMENT

class ElytraRecast : Module("Elytra Recast", ModCategory.MOVEMENT) {
    private val delay = num("Delay (ticks)", 3.0, 1.0, 20.0, 0)
    private var cd = 0

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (cd > 0) { cd--; return }
        if (!player.getItemBySlot(EquipmentSlot.CHEST).`is`(Items.ELYTRA)) return
        if (player.onGround() || player.isFallFlying || player.isInWater || player.deltaMovement.y >= 0.0) return
        if (player.tryToStartFallFlying()) {
            player.connection.send(
                ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.START_FALL_FLYING)
            )
            cd = delay.value.toInt()
        }
    }
}

class InfiniteElytra : Module("Infinite Elytra", ModCategory.MOVEMENT) {
    private val speed = num("Speed", 1.5, 0.5, 4.0, 1)

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (!player.isFallFlying) return
        player.deltaMovement = player.lookAngle.scale(speed.value)
    }
}

class ElytraTarget : Module("Elytra Target", ModCategory.MOVEMENT) {
    private val range = num("Range", 60.0, 10.0, 200.0, 0)
    private val turn = num("Turn Speed", 15.0, 1.0, 90.0, 0)
    private val aimHeight = num("Aim Height", 0.5, 0.0, 1.0, 2)
    private val sort = mode("Sort", listOf("Distance", "Health"))
    private val predict = bool("Predict Movement", true)
    private val ignoreNamed = bool("Ignore Named", false)

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val level = mc.level ?: return
        if (!player.isFallFlying || mc.screen != null) return
        val cands = level.players().filter {
            it !== player && it.isAlive && !it.isSpectator && player.distanceTo(it) <= range.value &&
                !(ignoreNamed.value && it.hasCustomName())
        }
        val target = (if (sort.index == 1) cands.minByOrNull { it.health }
        else cands.minByOrNull { player.distanceTo(it) }) ?: return

        var pos = Vec3(target.x, target.y + target.bbHeight * aimHeight.value, target.z)
        if (predict.value) {
            val ticks = (player.distanceTo(target) / maxOf(0.5, player.deltaMovement.length())).coerceAtMost(20.0)
            pos = pos.add(target.deltaMovement.scale(ticks))
        }
        val eye = player.eyePosition
        player.yRot = Rot.step(player.yRot, Rot.yawTo(eye, pos), turn.value.toFloat())
        player.xRot = Rot.step(player.xRot, Rot.pitchTo(eye, pos), turn.value.toFloat())
    }
}

class GuiMove : Module("Gui Move", ModCategory.MOVEMENT) {
    override fun onTick(mc: Minecraft) {
        val screen = mc.screen ?: return
        if (screen is ChatScreen) return
        KeyMapping.setAll()
    }
}

class LegitStrafe : Module("Legit Strafe", ModCategory.MOVEMENT) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (player.onGround() || player.isFallFlying || player.isInWater) return
        val fwd = player.zza.toDouble()
        val side = player.xxa.toDouble()
        if (fwd == 0.0 && side == 0.0) return
        val v = player.deltaMovement
        val speed = Math.hypot(v.x, v.z)
        if (speed < 0.05) return
        val yaw = Math.toRadians(player.yRot.toDouble())
        var dx = -Math.sin(yaw) * fwd + Math.cos(yaw) * side
        var dz = Math.cos(yaw) * fwd + Math.sin(yaw) * side
        val len = Math.hypot(dx, dz)
        if (len == 0.0) return
        dx /= len
        dz /= len
        player.setDeltaMovement(dx * speed, v.y, dz * speed)
    }
}

class HoleAnchor : Module("Hole Anchor", ModCategory.MOVEMENT) {
    private val depth = num("Depth", 3.0, 1.0, 5.0, 0)
    private val pull = num("Pull Strength", 0.3, 0.05, 1.0, 2)

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val level = mc.level ?: return
        val base = player.blockPosition()
        for (i in 1..depth.value.toInt()) {
            val p = base.below(i)
            if (Util.isHole(level, p)) {
                val v = player.deltaMovement
                player.setDeltaMovement(
                    (p.x + 0.5 - player.x) * pull.value, v.y, (p.z + 0.5 - player.z) * pull.value
                )
                return
            }
        }
    }
}

// ============================================================ VISUAL

abstract class HurtFx(name: String) : Module(name, ModCategory.VISUAL) {
    protected val range = num("Range", 12.0, 3.0, 32.0, 0)
    protected val amount = num("Amount", 8.0, 1.0, 30.0, 0)
    private val last = HashMap<Int, Int>()

    abstract fun particle(): net.minecraft.core.particles.ParticleOptions

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val level = mc.level ?: return
        if (last.size > 256) last.clear()
        val box = player.boundingBox.inflate(range.value)
        for (e in level.getEntities(null, box)) {
            if (e !is LivingEntity) continue
            val prev = last[e.id] ?: 0
            if (e.hurtTime > prev) {
                for (i in 0 until amount.value.toInt()) {
                    level.addParticle(
                        particle(),
                        e.x + (Math.random() - 0.5) * e.bbWidth,
                        e.y + Math.random() * e.bbHeight,
                        e.z + (Math.random() - 0.5) * e.bbWidth,
                        (Math.random() - 0.5) * 0.3, Math.random() * 0.2, (Math.random() - 0.5) * 0.3
                    )
                }
            }
            last[e.id] = e.hurtTime
        }
    }
}

class HitFx : HurtFx("Hit Fx") {
    private val type = mode("Particle", listOf("Crit", "Magic Crit", "Flame", "Heart"))
    override fun particle(): net.minecraft.core.particles.ParticleOptions = when (type.index) {
        1 -> ParticleTypes.ENCHANTED_HIT
        2 -> ParticleTypes.FLAME
        3 -> ParticleTypes.HEART
        else -> ParticleTypes.CRIT
    }
}

class DamageParticles : HurtFx("Damage Particles") {
    override fun particle(): net.minecraft.core.particles.ParticleOptions = ParticleTypes.DAMAGE_INDICATOR
}
