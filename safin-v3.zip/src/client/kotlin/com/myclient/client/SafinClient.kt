package com.myclient.client

import com.mojang.blaze3d.platform.InputConstants
import com.myclient.client.gui.ClickGuiScreen
import com.myclient.client.module.ModuleManager
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
import net.minecraft.client.KeyMapping
import net.minecraft.resources.Identifier
import org.lwjgl.glfw.GLFW

object SafinClient : ClientModInitializer {
	private lateinit var openGuiKey: KeyMapping

	override fun onInitializeClient() {
		val category = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath("safin", "main")
		)
		openGuiKey = KeyBindingHelper.registerKeyBinding(
			KeyMapping("key.safin.open_gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, category)
		)

		ClientTickEvents.END_CLIENT_TICK.register { mc ->
			while (openGuiKey.consumeClick()) {
				if (mc.screen == null) mc.setScreen(ClickGuiScreen())
			}
			if (mc.player != null && mc.level != null) {
				ModuleManager.tick(mc)
			}
		}
	}
}
