package com.myclient.client.gui

import com.myclient.client.module.BoolSetting
import com.myclient.client.module.ModCategory
import com.myclient.client.module.Module
import com.myclient.client.module.ModeSetting
import com.myclient.client.module.ModuleManager
import com.myclient.client.module.NumSetting
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.client.gui.screens.Screen
import net.minecraft.client.input.MouseButtonEvent
import net.minecraft.network.chat.Component
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

// ---- colors (ARGB, alpha must be FF or the text/rects are invisible) ----
private val DIM = 0x88000000.toInt()
private val PANEL = 0xF0101018.toInt()
private val HEADER = 0xFF1B1736.toInt()
private val ROW = 0xFF171722.toInt()
private val ROW_HOVER = 0xFF202033.toInt()
private val ROW_ON = 0xFF3B2F7A.toInt()
private val ROW_OFF_DIM = 0xFF121218.toInt()
private val TEXT = 0xFFD7D4FF.toInt()
private val TEXT_DIM = 0xFF55536E.toInt()
private val ACCENT_TEXT = 0xFF8F7CFF.toInt()
private val ACCENT = 0xFF6A4DFF.toInt()
private val SLIDER = 0xFF2B2BFF.toInt()
private val TRACK = 0xFF0B0B12.toInt()

private class Hit(
    val x1: Int, val y1: Int, val x2: Int, val y2: Int,
    val clip: IntArray,
    val onClick: (Int) -> Unit = {},
    val onDrag: ((Double) -> Unit)? = null
)

private class Area(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val key: String)

class ClickGuiScreen : Screen(Component.literal("Safin")) {
    private var selected: Module? = null
    private val hits = ArrayList<Hit>()
    private val areas = ArrayList<Area>()
    private val scroll = HashMap<String, Double>()
    private val maxScroll = HashMap<String, Double>()

    private var pressX = 0.0
    private var pressY = 0.0
    private var dragged = false
    private var pressedHit: Hit? = null
    private var activeDrag: Hit? = null

    private fun select(m: Module?) {
        selected = m
        scroll["settings"] = 0.0
    }

    // ------------------------------------------------------------------ drawing
    private fun roundRect(g: GuiGraphics, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        g.fill(x1 + 2, y1, x2 - 2, y2, color)
        g.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, color)
        g.fill(x1, y1 + 2, x2, y2 - 2, color)
    }

    private fun inside(mx: Int, my: Int, x1: Int, y1: Int, x2: Int, y2: Int) =
        mx >= x1 && mx < x2 && my >= y1 && my < y2

    override fun render(g: GuiGraphics, mouseX: Int, mouseY: Int, delta: Float) {
        super.render(g, mouseX, mouseY, delta)
        g.fill(0, 0, width, height, DIM)
        hits.clear()
        areas.clear()

        val cats = ModCategory.values()
        val gap = 6
        val pw = minOf(130, (width - 12 - gap * (cats.size - 1)) / cats.size)
        val total = cats.size * pw + (cats.size - 1) * gap
        var x = (width - total) / 2
        val top = 14
        val bottom = height - 10
        for (cat in cats) {
            drawCategory(g, cat, x, top, pw, bottom - top, mouseX, mouseY)
            x += pw + gap
        }
        selected?.let { drawSettings(g, it, mouseX, mouseY) }
    }

    private fun drawCategory(g: GuiGraphics, cat: ModCategory, x: Int, y: Int, w: Int, h: Int, mx: Int, my: Int) {
        roundRect(g, x, y, x + w, y + h, PANEL)
        roundRect(g, x, y, x + w, y + 20, HEADER)
        g.drawString(font, cat.title, x + (w - font.width(cat.title)) / 2, y + 6, ACCENT_TEXT)

        val listTop = y + 24
        val listBottom = y + h - 4
        val rowH = 18
        val mods = ModuleManager.inCategory(cat)
        val max = maxOf(0, mods.size * rowH - (listBottom - listTop)).toDouble()
        maxScroll[cat.title] = max
        val off = (scroll[cat.title] ?: 0.0).coerceIn(0.0, max)
        scroll[cat.title] = off
        areas.add(Area(x, listTop, x + w, listBottom, cat.title))

        val clip = intArrayOf(x, listTop, x + w, listBottom)
        g.enableScissor(x, listTop, x + w, listBottom)
        var ry = listTop - off.toInt()
        for (m in mods) {
            if (ry + rowH > listTop && ry < listBottom) {
                val rx1 = x + 4
                val rx2 = x + w - 4
                val hovered = inside(mx, my, rx1, ry, rx2, ry + rowH - 2) &&
                    inside(mx, my, clip[0], clip[1], clip[2], clip[3]) && selected == null
                val bg = when {
                    !m.implemented -> ROW_OFF_DIM
                    m.enabled -> ROW_ON
                    hovered -> ROW_HOVER
                    else -> ROW
                }
                roundRect(g, rx1, ry, rx2, ry + rowH - 2, bg)
                val color = if (m.implemented) TEXT else TEXT_DIM
                g.drawString(font, m.name, rx1 + 6, ry + 5, color)
                hits.add(Hit(rx1, ry, rx2, ry + rowH - 2, clip, { btn ->
                    if (btn == 1) {
                        if (m.settings.isNotEmpty()) select(m)
                    } else {
                        m.toggle()
                    }
                }))
                if (m.settings.isNotEmpty()) {
                    g.drawString(font, "...", rx2 - 16, ry + 4, ACCENT_TEXT)
                    hits.add(Hit(rx2 - 20, ry, rx2, ry + rowH - 2, clip, { select(m) }))
                }
            }
            ry += rowH
        }
        g.disableScissor()
    }

    private fun settingHeight(s: com.myclient.client.module.Setting) = if (s is NumSetting) 28 else 18

    private fun drawSettings(g: GuiGraphics, m: Module, mx: Int, my: Int) {
        val pw = minOf(200, width - 16)
        val x = (width - pw) / 2
        val y = 10
        val h = height - 20
        val full = intArrayOf(0, 0, width, height)

        hits.add(Hit(x, y, x + pw, y + h, full))
        roundRect(g, x - 1, y - 1, x + pw + 1, y + h + 1, ACCENT)
        roundRect(g, x, y, x + pw, y + h, PANEL)
        roundRect(g, x, y, x + pw, y + 22, HEADER)
        g.drawString(font, "<", x + 9, y + 7, ACCENT_TEXT)
        hits.add(Hit(x, y, x + 26, y + 22, full, { select(null) }))
        g.drawString(font, m.name, x + (pw - font.width(m.name)) / 2, y + 7, ACCENT_TEXT)

        val listTop = y + 26
        val listBottom = y + h - 4
        val visible = m.settings.filter { it.showIf() }
        val content = visible.sumOf { settingHeight(it) }
        val max = maxOf(0, content - (listBottom - listTop)).toDouble()
        maxScroll["settings"] = max
        val off = (scroll["settings"] ?: 0.0).coerceIn(0.0, max)
        scroll["settings"] = off
        areas.add(Area(x, listTop, x + pw, listBottom, "settings"))

        val clip = intArrayOf(x, listTop, x + pw, listBottom)
        g.enableScissor(x, listTop, x + pw, listBottom)
        var ry = listTop - off.toInt()
        for (s in visible) {
            val rh = settingHeight(s)
            if (ry + rh > listTop && ry < listBottom) {
                drawSetting(g, s, x + 6, ry, pw - 12, rh - 2, clip)
            }
            ry += rh
        }
        g.disableScissor()
    }

    private fun drawSetting(g: GuiGraphics, s: com.myclient.client.module.Setting, x: Int, y: Int, w: Int, h: Int, clip: IntArray) {
        roundRect(g, x, y, x + w, y + h, ROW)
        g.drawString(font, s.name, x + 6, y + 4, TEXT)
        when (s) {
            is BoolSetting -> {
                val bx = x + w - 16
                g.fill(bx, y + 3, bx + 10, y + 13, TRACK)
                if (s.value) g.fill(bx + 2, y + 5, bx + 8, y + 11, ACCENT)
                hits.add(Hit(x, y, x + w, y + h, clip, { s.value = !s.value }))
            }
            is ModeSetting -> {
                val v = s.value
                g.drawString(font, v, x + w - 6 - font.width(v), y + 4, ACCENT_TEXT)
                hits.add(Hit(x, y, x + w, y + h, clip, { s.next() }))
            }
            is NumSetting -> {
                val v = String.format(Locale.ROOT, "%." + s.decimals + "f", s.value)
                g.drawString(font, v, x + w - 6 - font.width(v), y + 4, ACCENT_TEXT)
                val tx = x + 6
                val tw = w - 12
                val ty = y + 17
                g.fill(tx, ty, tx + tw, ty + 4, TRACK)
                val ratio = ((s.value - s.min) / (s.max - s.min)).coerceIn(0.0, 1.0)
                val fillX = tx + (tw * ratio).toInt()
                g.fill(tx, ty, fillX, ty + 4, SLIDER)
                g.fill(fillX - 2, ty - 2, fillX + 2, ty + 6, TEXT)
                hits.add(Hit(x, y + 12, x + w, y + h, clip, {}, { px ->
                    val r = ((px - tx) / tw).coerceIn(0.0, 1.0)
                    val raw = s.min + r * (s.max - s.min)
                    val p = 10.0.pow(s.decimals)
                    s.value = Math.round(raw * p) / p
                }))
            }
        }
    }

    // ------------------------------------------------------------------ input
    private fun hitAt(mx: Double, my: Double): Hit? =
        hits.lastOrNull {
            mx >= it.x1 && mx < it.x2 && my >= it.y1 && my < it.y2 &&
                mx >= it.clip[0] && mx < it.clip[2] && my >= it.clip[1] && my < it.clip[3]
        }

    override fun mouseClicked(event: MouseButtonEvent, doubleClick: Boolean): Boolean {
        val mx = event.x()
        val my = event.y()
        pressX = mx
        pressY = my
        dragged = false
        pressedHit = hitAt(mx, my)
        val h = pressedHit
        activeDrag = if (h?.onDrag != null) h else null
        activeDrag?.onDrag?.invoke(mx)
        return true
    }

    override fun mouseDragged(event: MouseButtonEvent, dragX: Double, dragY: Double): Boolean {
        val drag = activeDrag
        if (drag != null) {
            drag.onDrag?.invoke(event.x())
            return true
        }
        if (abs(event.x() - pressX) + abs(event.y() - pressY) > 4.0) dragged = true
        if (dragged) scrollAt(pressX, pressY, -dragY)
        return true
    }

    override fun mouseReleased(event: MouseButtonEvent): Boolean {
        if (!dragged && activeDrag == null) pressedHit?.onClick?.invoke(event.button())
        pressedHit = null
        activeDrag = null
        dragged = false
        return true
    }

    override fun mouseScrolled(mouseX: Double, mouseY: Double, scrollX: Double, scrollY: Double): Boolean {
        scrollAt(mouseX, mouseY, -scrollY * 18.0)
        return true
    }

    private fun scrollAt(mx: Double, my: Double, amount: Double) {
        val area = areas.lastOrNull { mx >= it.x1 && mx < it.x2 && my >= it.y1 && my < it.y2 } ?: return
        val max = maxScroll[area.key] ?: 0.0
        scroll[area.key] = ((scroll[area.key] ?: 0.0) + amount).coerceIn(0.0, max)
    }
}
