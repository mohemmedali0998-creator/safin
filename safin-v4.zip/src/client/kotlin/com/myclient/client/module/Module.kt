package com.myclient.client.module

import net.minecraft.client.Minecraft

enum class ModCategory(val title: String) {
    PVP("Pvp"),
    MOVEMENT("Movement"),
    VISUAL("Visual")
}

sealed class Setting(val name: String) {
    var showIf: () -> Boolean = { true }
}

class BoolSetting(name: String, var value: Boolean) : Setting(name)

class NumSetting(
    name: String,
    var value: Double,
    val min: Double,
    val max: Double,
    val decimals: Int = 1
) : Setting(name)

class ModeSetting(name: String, val options: List<String>, var index: Int = 0) : Setting(name) {
    val value: String get() = options[index]
    fun next() {
        index = (index + 1) % options.size
    }
}

abstract class Module(val name: String, val category: ModCategory) {
    var enabled: Boolean = false
        private set

    val settings: MutableList<Setting> = mutableListOf()

    open val implemented: Boolean get() = true
    open val toggleable: Boolean get() = true

    protected fun bool(name: String, default: Boolean): BoolSetting =
        BoolSetting(name, default).also { settings.add(it) }

    protected fun num(name: String, default: Double, min: Double, max: Double, decimals: Int = 1): NumSetting =
        NumSetting(name, default, min, max, decimals).also { settings.add(it) }

    protected fun mode(name: String, options: List<String>, index: Int = 0): ModeSetting =
        ModeSetting(name, options, index).also { settings.add(it) }

    open fun onEnable() {}
    open fun onDisable() {}
    open fun onTick(mc: Minecraft) {}

    fun toggle() {
        if (implemented && toggleable) setState(!enabled)
    }

    fun setState(value: Boolean) {
        if (value == enabled) return
        enabled = value
        if (value) onEnable() else onDisable()
    }
}

/** A module that is listed in the menu but not written yet. */
class Planned(name: String, category: ModCategory) : Module(name, category) {
    override val implemented: Boolean get() = false
}

/** Settings-only entry that controls how the menu looks. */
class ThemeModule : Module("Theme", ModCategory.VISUAL) {
    override val toggleable: Boolean get() = false

    val accentMode = mode("Accent", listOf("Purple", "Blue", "Pink", "Green", "Red", "Cyan"))
    val opacity = num("Panel Opacity", 94.0, 40.0, 100.0, 0)
    val dim = bool("Dim Background", true)

    private val accents = intArrayOf(0xFF6A4DFF.toInt(), 0xFF3D7BFF.toInt(), 0xFFFF4D9D.toInt(), 0xFF3DDC84.toInt(), 0xFFFF4D4D.toInt(), 0xFF22D3EE.toInt())
    private val rowsOn = intArrayOf(0xFF3B2F7A.toInt(), 0xFF1F3F85.toInt(), 0xFF7A2A55.toInt(), 0xFF1F6B45.toInt(), 0xFF7A2A2A.toInt(), 0xFF146A78.toInt())
    private val lights = intArrayOf(0xFF8F7CFF.toInt(), 0xFF7FAAFF.toInt(), 0xFFFF86BE.toInt(), 0xFF7BF0AE.toInt(), 0xFFFF8686.toInt(), 0xFF7BE8FA.toInt())

    fun accent(): Int = accents[accentMode.index]
    fun rowOn(): Int = rowsOn[accentMode.index]
    fun light(): Int = lights[accentMode.index]
    fun panelColor(): Int = ((opacity.value / 100.0 * 255.0).toInt() shl 24) or 0x101018
}

object ModuleManager {
    val theme = ThemeModule()

    private val plannedPvp = listOf(
        "Anti Phase", "Attribute Swap", "Auto Base Place", "Auto Crystal", "Auto Dripstone",
        "Auto Mine", "Auto Netherite Scrap", "Auto Sweet Berries", "Auto Web", "Criticals",
        "Hole Filler", "Mace Killer", "More Knockback", "Trap"
    )
    private val plannedMovement = listOf(
        "Anti Knock Back", "Avoid", "Elytra Recast", "Elytra Target", "Gui Move", "Hole Anchor",
        "Infinite Elytra", "Legit Strafe", "Move Fix", "No Push", "Wind Hop"
    )
    private val plannedVisual = listOf(
        "Absorption", "Aspect", "Buff Effect", "Crystal Chams", "Damage Particles", "Damage Tint",
        "Dismemberment", "Free Look", "Hand Chams", "Hit Fx", "No Camera Clip", "Particles",
        "Pop Chams", "Sky Lanterns", "Swing Animations", "Throw Petard", "Totem Animation",
        "Trajectories", "View Model", "World Renderer"
    )

    val modules: List<Module> = buildList {
        add(theme)
        add(Aura())
        add(TriggerBot())
        add(Sprint())
        add(BunnyHop())
        add(FullBright())
        plannedPvp.forEach { add(Planned(it, ModCategory.PVP)) }
        plannedMovement.forEach { add(Planned(it, ModCategory.MOVEMENT)) }
        plannedVisual.forEach { add(Planned(it, ModCategory.VISUAL)) }
    }.sortedBy { it.name }

    fun inCategory(category: ModCategory): List<Module> =
        modules.filter { it.category == category }

    fun tick(mc: Minecraft) {
        for (m in modules) {
            if (m.enabled) m.onTick(mc)
        }
    }
}
