package com.myclient.client

import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.myclient.client.module.BoolSetting
import com.myclient.client.module.ModeSetting
import com.myclient.client.module.ModuleManager
import com.myclient.client.module.NumSetting
import net.fabricmc.loader.api.FabricLoader
import java.nio.file.Files

/** Saves and loads every setting to config/safin.json. */
object Config {
    private fun file() = FabricLoader.getInstance().configDir.resolve("safin.json")

    fun save() {
        try {
            val root = JsonObject()
            for (m in ModuleManager.modules) {
                if (!m.implemented) continue
                val o = JsonObject()
                if (m.toggleable) o.addProperty("enabled", m.enabled)
                for (s in m.settings) {
                    when (s) {
                        is BoolSetting -> o.addProperty(s.name, s.value)
                        is NumSetting -> o.addProperty(s.name, s.value)
                        is ModeSetting -> o.addProperty(s.name, s.index)
                    }
                }
                root.add(m.name, o)
            }
            Files.writeString(file(), GsonBuilder().setPrettyPrinting().create().toJson(root))
        } catch (e: Exception) {
            // saving is best effort
        }
    }

    fun load() {
        try {
            val f = file()
            if (!Files.exists(f)) return
            val root = JsonParser.parseString(Files.readString(f)).asJsonObject
            for (m in ModuleManager.modules) {
                if (!m.implemented) continue
                if (!root.has(m.name)) continue
                val o = root.getAsJsonObject(m.name)
                if (m.toggleable && o.has("enabled")) m.setState(o.get("enabled").asBoolean)
                for (s in m.settings) {
                    if (!o.has(s.name)) continue
                    when (s) {
                        is BoolSetting -> s.value = o.get(s.name).asBoolean
                        is NumSetting -> s.value = o.get(s.name).asDouble.coerceIn(s.min, s.max)
                        is ModeSetting -> s.index = o.get(s.name).asInt.coerceIn(0, s.options.size - 1)
                    }
                }
            }
        } catch (e: Exception) {
            // ignore a broken config file
        }
    }
}
