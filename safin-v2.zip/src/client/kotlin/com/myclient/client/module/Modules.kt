package com.myclient.client.module

import net.minecraft.client.Minecraft
import net.minecraft.world.InteractionHand
import net.minecraft.world.effect.MobEffectInstance
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.Mob
import net.minecraft.world.entity.decoration.ArmorStand
import net.minecraft.world.entity.monster.Enemy

/** Attacks the nearest target in range (for your own single-player world). */
class Aura : Module("Aura", ModCategory.PVP) {
    private val range = NumSetting("Range", 3.0, 2.0, 6.0)
    private val hostiles = BoolSetting("Hostiles", true)
    private val passives = BoolSetting("Passive Mobs", false)

    init {
        settings.add(range)
        settings.add(hostiles)
        settings.add(passives)
    }

    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val gameMode = mc.gameMode ?: return
        val level = mc.level ?: return
        if (mc.screen != null) return
        if (player.getAttackStrengthScale(0f) < 1f) return

        val r = range.value
        val box = player.boundingBox.inflate(r)
        val target = level.getEntities(player, box)
            .filterIsInstance<LivingEntity>()
            .filter { e ->
                e.isAlive && e !is ArmorStand && player.distanceTo(e) <= r &&
                    ((hostiles.value && e is Enemy) || (passives.value && e is Mob && e !is Enemy))
            }
            .minByOrNull { player.distanceTo(it) } ?: return

        gameMode.attack(player, target)
        player.swing(InteractionHand.MAIN_HAND)
    }
}

class Sprint : Module("Sprint", ModCategory.MOVEMENT) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        if (player.zza > 0f && !player.isUsingItem && !player.horizontalCollision) {
            player.isSprinting = true
        }
    }
}

class FullBright : Module("Full Bright", ModCategory.VISUAL) {
    override fun onTick(mc: Minecraft) {
        val player = mc.player ?: return
        val current = player.getEffect(MobEffects.NIGHT_VISION)
        if (current == null || current.duration < 300) {
            player.addEffect(MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false, false))
        }
    }

    override fun onDisable() {
        Minecraft.getInstance().player?.removeEffect(MobEffects.NIGHT_VISION)
    }
}
