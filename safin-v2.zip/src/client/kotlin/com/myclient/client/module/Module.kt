package com.myclient.client.module

import net.minecraft.client.Minecraft

enum class ModCategory(val title: String) {
    PVP("Pvp"),
    MOVEMENT("Movement"),
    VISUAL("Visual")
}

sealed class Setting(val name: String)
class BoolSetting(name: String, var value: Boolean) : Setting(name)
class NumSetting(name: String, var value: Double, val min: Double, val max: Double) : Setting(name)

abstract class Module(val name: String, val category: ModCategory) {
    var enabled: Boolean = false
        private set

    val settings: MutableList<Setting> = mutableListOf()

    open fun onEnable() {}
    open fun onDisable() {}
    open fun onTick(mc: Minecraft) {}

    fun toggle() = setState(!enabled)

    fun setState(value: Boolean) {
        if (value == enabled) return
        enabled = value
        if (value) onEnable() else onDisable()
    }
}

object ModuleManager {
    val modules: List<Module> = listOf(Aura(), Sprint(), FullBright())

    fun inCategory(category: ModCategory): List<Module> =
        modules.filter { it.category == category }

    fun tick(mc: Minecraft) {
        for (m in modules) {
            if (m.enabled) m.onTick(mc)
        }
    }
}
