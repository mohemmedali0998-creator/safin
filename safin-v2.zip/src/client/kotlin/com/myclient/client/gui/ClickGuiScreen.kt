package com.myclient.client.gui

import com.myclient.client.module.BoolSetting
import com.myclient.client.module.ModCategory
import com.myclient.client.module.Module
import com.myclient.client.module.ModuleManager
import com.myclient.client.module.NumSetting
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.components.AbstractSliderButton
import net.minecraft.client.gui.components.Button
import net.minecraft.client.gui.screens.Screen
import net.minecraft.network.chat.Component
import java.util.Locale

private fun moduleLabel(m: Module): Component =
    Component.literal(m.name + ": " + if (m.enabled) "ON" else "OFF")

private fun boolLabel(s: BoolSetting): Component =
    Component.literal(s.name + ": " + if (s.value) "ON" else "OFF")

class ClickGuiScreen : Screen(Component.literal("Safin")) {
    override fun init() {
        val cats = ModCategory.values()
        val colW = 120
        val gap = 8
        val total = cats.size * colW + (cats.size - 1) * gap
        val startX = (width - total) / 2

        cats.forEachIndexed { i, cat ->
            val x = startX + i * (colW + gap)
            var y = 20

            val header = Button.builder(Component.literal(cat.title)) { }
                .bounds(x, y, colW, 20).build()
            header.active = false
            addRenderableWidget(header)
            y += 24

            for (m in ModuleManager.inCategory(cat)) {
                val toggleW = if (m.settings.isNotEmpty()) colW - 26 else colW
                addRenderableWidget(
                    Button.builder(moduleLabel(m)) { b ->
                        m.toggle()
                        b.message = moduleLabel(m)
                    }.bounds(x, y, toggleW, 20).build()
                )
                if (m.settings.isNotEmpty()) {
                    addRenderableWidget(
                        Button.builder(Component.literal("...")) {
                            Minecraft.getInstance().setScreen(SettingsScreen(m, this))
                        }.bounds(x + colW - 24, y, 24, 20).build()
                    )
                }
                y += 22
            }
        }
    }
}

class SettingsScreen(private val module: Module, private val parent: Screen) :
    Screen(Component.literal(module.name)) {

    override fun init() {
        val w = 200
        val x = (width - w) / 2
        var y = 20

        val header = Button.builder(Component.literal(module.name)) { }
            .bounds(x, y, w, 20).build()
        header.active = false
        addRenderableWidget(header)
        y += 28

        for (s in module.settings) {
            when (s) {
                is BoolSetting -> addRenderableWidget(
                    Button.builder(boolLabel(s)) { b ->
                        s.value = !s.value
                        b.message = boolLabel(s)
                    }.bounds(x, y, w, 20).build()
                )
                is NumSetting -> addRenderableWidget(NumSlider(x, y, w, 20, s))
            }
            y += 24
        }

        addRenderableWidget(
            Button.builder(Component.literal("Back")) { onClose() }
                .bounds(x, y + 8, w, 20).build()
        )
    }

    override fun onClose() {
        Minecraft.getInstance().setScreen(parent)
    }
}

private class NumSlider(x: Int, y: Int, w: Int, h: Int, private val setting: NumSetting) :
    AbstractSliderButton(
        x, y, w, h, Component.empty(),
        (setting.value - setting.min) / (setting.max - setting.min)
    ) {

    init {
        updateMessage()
    }

    override fun updateMessage() {
        message = Component.literal(setting.name + ": " + String.format(Locale.ROOT, "%.1f", setting.value))
    }

    override fun applyValue() {
        setting.value = setting.min + (setting.max - setting.min) * value
    }
}
